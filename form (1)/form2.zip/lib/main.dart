import 'package:flutter/material.dart';
import 'package:flutterapp/form2app/generatedform2widget/GeneratedForm2Widget.dart';

void main() {
  runApp(form2App());
}

class form2App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Form',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedForm2Widget',
      routes: {
        '/GeneratedForm2Widget': (context) => GeneratedForm2Widget(),
      },
    );
  }
}
